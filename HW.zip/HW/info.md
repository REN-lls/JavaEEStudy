#表白神器
##功能一
    获取天气
###天气查询
    地址：https://itdage.cn/hw/weather
    参数：city--所要查询的城市
##功能二
    发送信息
###发送短信
    地址：https://itdage.cn/hw/hwSms
    参数
        1. name:姓名
        2. phone：电话号码
        3. s1:天气信息
        4. s2:温度区间
        5. s3:温馨提示
    返回实例：
        成功：ok
        失败：原因
package com.xhu.controller;

import com.xhu.bean.User;
import com.xhu.utils.Application;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(value = {"/tart.html"})
public class StartFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        User user = (User) Application.get("user");
        if (user != null) {
            HttpServletResponse response = (HttpServletResponse) resp;
            response.sendRedirect("index.html");
        } else
            chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}

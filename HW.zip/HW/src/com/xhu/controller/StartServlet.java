package com.xhu.controller;

import com.xhu.bean.JSONMessage;
import com.xhu.utils.SMSTask;
import com.xhu.utils.Utils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/start")
public class StartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 设置请求响应编码
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/json;charset=utf-8");
        //2. 通过请求获取数据
        String name = request.getParameter("name");
        String phoneNumber = request.getParameter("phoneNumber");
        String city = request.getParameter("city");
        //3. 通过数据传入发送函数实现发送功能
        boolean flag  = SMSTask.start(1000 * 60 * 60,name, phoneNumber, city);
        //4. 通过响应返回数据
        JSONMessage jm = null;
        if(flag)
            jm = new JSONMessage(0,"ok");
        else
            jm = new JSONMessage(-1,"fail");
        response.getWriter().append(jm.toJSON());
    }
}

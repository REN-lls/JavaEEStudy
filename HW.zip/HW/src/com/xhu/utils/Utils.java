package com.xhu.utils;

import com.xhu.bean.Message;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Utils {

    /**
     * 读取天气API，获取详细的天气信息,爬虫面向监狱编程
     *
     * @return
     */
    private static String getdata(String url) {
        //1. 网址对象
        try {
            URL u = new URL(url);

            //2. 打开链接
            URLConnection conn = u.openConnection();
            //3.获取字节流，再装饰成字符，进入字符缓冲流
            InputStream is = conn.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            //4.读数据
            StringBuffer sb = new StringBuffer();
            String data = null;
            while ((data = br.readLine()) != null) {
                sb.append(data);
            }
            //5.返回数据给调用者
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getweather(String city) {
        try {
            String weather = getdata("https://itdage.cn/hw/weather?city=" + URLEncoder.encode(city, "UTF-8"));
            return weather;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String sendSms(String name, String phoneNumber, String s1, String s2, String s3) {

        try {
            name = URLEncoder.encode(name, "UTF-8");

            s1 = URLEncoder.encode(s1, "utf-8");

            s2 = URLEncoder.encode(s2, "utf-8");

            s3 = URLEncoder.encode(s3, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String code = getdata("https://itdage.cn/hw/hwSms?name=" + name + "&phoneNumber=" + phoneNumber + "&s1=" + s1 + "&s2=" + s2 + "&s3=" + s3);
        return code;
    }

    public static String send(String city, String name, String phoneNumber) {
        //1. 获取天气信息
        String data = getweather(city);
        ParseJSON j = new ParseJSON(data);
        String s1 = j.getWeather();
        String lowtemp = j.getTemp().get("low"), hightemp = j.getTemp().get("high");
        String s2 = lowtemp + "-" + hightemp + "度";
        Map<String, String> tip = j.getTips();
        String s3 = tip.values().toString();
        //2. 发送文件
        String code = sendSms(name, phoneNumber, s1, s2, s3);
        //3.短信信息存储入bean-Message
        Message m = Message.getInstance();
        if (code.equalsIgnoreCase("OK")) {
            //0. 格式转化，返回接口要求的数据封装类型
            //1. 更新表白信息的关怀类型与数量
            String wname = tip.keySet().toArray()[0].toString();
            m.addSmsType(wname);
            //2. 更新未来五天温度变化
            HashMap<String, ArrayList<String>> temps = j.getTemps();
            m.setTemp(temps);
            //3. 更新温度区间天数分布
            int temptype = 0;
            int low = Integer.parseInt(lowtemp);
            int high = Integer.parseInt(hightemp);
            temptype = high < 0 ? 0 : high < 10 ? 1 : high < 20 ? 2 : high < 30 ? 3 : 4;
            m.addTempTypeCount(temptype);
            //4. 更新至今风向数据分布
            String wd = j.getWinddirect();
            m.addWindirect(wd);
            //5. 更新未来五天风速大小
            HashMap<String, ArrayList<String>> ws = j.getWindpowers();
            m.setWindpower(ws);
            //6. 更新至今天气类型占比
            m.addWeatherTypeCount(s1);
            //7. 更新追求天数和心跳次数
        }
        //4. 返回状态
        System.out.println(code);

        return code;
    }


}

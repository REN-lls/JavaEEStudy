package com.xhu.utils;

import com.xhu.bean.Message;
import com.xhu.bean.User;

public class SMSTask {
    private static boolean flag = false;
    private static Thread t1;

    public static boolean start(long time, String name, String phoneNumber, String city) {
        //存储追求天数，心跳次数，发送过的信息，全局就一个Message，只创建一次就是在线程跑起来的时候
        Message m = Message.getInstance();
        if (!flag) {
            final String[] code = {""};
            t1 = new Thread(() -> {
                task:
                while (!flag) {
                    code[0] = Utils.send(city, name, phoneNumber);
                    if (!"OK".equalsIgnoreCase(code[0]))
                        continue;
                    try {
                        Thread.sleep(time);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        break task;
                    }
                }
            });
            t1.start();

            while (true){
                if ("OK".equalsIgnoreCase(code[0])) {
                    //用户信息存入bean-User
                    Application.put("user", new User(name, phoneNumber, city));
                    return true;
                }
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    public static void end() {
        flag = true;
        if (t1 != null && !t1.isInterrupted()) {
            t1.interrupt();
        }
    }

/*    public static void main(String[] args) {
        long time = 1000 * 60 * 60;
        String city = "成都";
        String name ="小雨朵";
        String phoneNumber = "15883700902";
        start(time, name, phoneNumber, city);
    }*/

}

